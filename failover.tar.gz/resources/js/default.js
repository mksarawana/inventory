var app = angular.module("failOver", ['ui.bootstrap', 'angularFileUpload']);

app.service('triggerProcess', ['$http',"$q", function ($http,$q) {
    this.initiate = function(scriptUrl){
        var deferred = $q.defer();
        $http.get(scriptUrl).then(
            function(response){
                deferred.resolve(response);
            },
            function(error){
                deferred.resolve(error);
            }
        );
        return deferred.promise;
     }
 }]);

app.controller("failOverCtrl",['$scope', 'FileUploader','triggerProcess',function($scope, FileUploader, triggerProcess) {
    $scope.testInProgress = false;
    $scope.user = {};
    // FOR TOGGLE BUTTON
    $scope.runMode = { single: false, bulk: true };
    $scope.radioModel = 'bulk';
    $scope.$watch('radioModel', function (newValue, oldValue, scope) {
        if($scope.radioModel == 'bulk'){
            $scope.runMode = { single: false, bulk: true };
        }else{
            $scope.runMode = { single: true, bulk: false };
        }
    });
    
    // FILE DOWNLOAD FUNCTIONALITY
    $scope.download = function(){
        triggerProcess.initiate('controller.php?action=download&filename='+$scope.filename).then(function(response){
            console.log(response);
            window.open('controller.php?action=download&filename='+$scope.filename);
        });
    };
    
    // TRIGGER EXECUTION OF SCRIPT
    $scope.start = function(){
        console.log($scope.user.userid);
        return false;
        console.log($scope.filename);
        if($scope.filename != ""){
            $scope.testInProgress = true;
            triggerProcess.initiate('controller.php?action=executetests&filename='+$scope.filename+'&userid='+$scope.user.userid).then(function(response){
                if(response.data.success){response.data.type = 'success';}
                console.log(response.data);
                $scope.logFile = response.data;
                $scope.testInProgress = false;
                $scope.alerts = [];
                $scope.alerts.push(response.data);
            }); 
        }
    };
   
    // UPLOAD FUNCTIONALITY FOR BULK CSV FILE
    var uploader = $scope.uploader = new FileUploader({
        url: 'controller.php?action=uploadfile'
    });
    
    // CALLBACKS
    uploader.onWhenAddingFileFailed = function(item /*{File|FileLikeObject}*/, filter, options) {
        console.info('onWhenAddingFileFailed', item, filter, options);
    };
    uploader.onAfterAddingFile = function(fileItem) {
        console.info('onAfterAddingFile', fileItem);
    };
    uploader.onAfterAddingAll = function(addedFileItems) {
        console.info('onAfterAddingAll', addedFileItems);
    };
    uploader.onBeforeUploadItem = function(item) {
        console.info('onBeforeUploadItem', item);
    };
    uploader.onProgressItem = function(fileItem, progress) {
        console.info('onProgressItem', fileItem, progress);
    };
    uploader.onProgressAll = function(progress) {
        console.info('onProgressAll', progress);
    };
    uploader.onSuccessItem = function(fileItem, response, status, headers) {
        console.info('onSuccessItem', fileItem, response, status, headers);
    };
    uploader.onErrorItem = function(fileItem, response, status, headers) {
        console.info('onErrorItem', fileItem, response, status, headers);
    };
    uploader.onCancelItem = function(fileItem, response, status, headers) {
        console.info('onCancelItem', fileItem, response, status, headers);
    };
    uploader.onCompleteItem = function(fileItem, response, status, headers) {
        console.info('onCompleteItem', fileItem, response, status, headers);
        $scope.filename = fileItem.file.name;
        if(response.success){response.type = 'success';}
        $scope.alerts = [];
        $scope.alerts.push(response);
    };
    uploader.onCompleteAll = function() {
        console.info('onCompleteAll');
        uploader.queue = [];
    };
    
    $scope.closeAlert = function(){
        $scope.alerts = [];
    };
}]);