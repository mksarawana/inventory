 <?php
    parse_str($_SERVER['QUERY_STRING']);
    if(isset($action)){
        switch($action){
            case "uploadfile"   :   
                if ( !empty( $_FILES ) ) {
                    
                    $tempPath = $_FILES[ 'file' ][ 'tmp_name' ];
                    $uploadPath = dirname( __FILE__ ) . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . $_FILES["file"]["name"];
                    
                    $result = move_uploaded_file( $tempPath, $uploadPath );
                     
                    if($result){
                        $response = array(  
                                            'success' => true,
                                            'message' => 'File uploaded successfully.' 
                                        );
                    }else{
                        $response = array( 
                                            'success' => false,
                                            'message' => 'Error: File could not be uploaded!' 
                                        );
                    }
                    
                }else{
                    $response = array( 
                                        'success' => false,
                                        'message' => 'No files selected!' 
                                    );
                }
                break;
                                    
            case "executetests" :
                
                $x = '/home/sarava/TART.py '.$filename.' '.$userid.' 2>&1';
                exec($x, $output, $returnVal);
                #if($returnVal){
                    
                    //Process filename from the last line of the log.
                    $tempFileName = '';
                    $logWithZipFileName = (is_array($output))?end($output):"";
                    #$logWithZipFileName = "('File saved path : ', '/var/www/html/failovertests/logs/filename.tar.gz')";
                    if($logWithZipFileName!="" && strpos($logWithZipFileName, '.tar.gz')!==false){
                        $fileInfo = new SplFileInfo($logWithZipFileName);
                        $fileNameArray = explode(".tar.gz",$fileInfo->getFilename());
                        $tempFileName = $fileNameArray[0].'.tar.gz';
                    }

                    $response = array( 
                        'success'   => true,
                        'name'      => $tempFileName,
                        'content'   => implode("\n", $output),
                        'message'   => 'Process execution triggerred successfully!'
                    );
                /* }else{
                    $response = array( 
                        'success'   => false,
                        'message'   => 'Process terminated unexpectedly!'
                    );
                } */
                break;
            
            case "download"     :   
                $zip = dirname( __FILE__ ) . DIRECTORY_SEPARATOR . 'logs'. DIRECTORY_SEPARATOR . $filename;
                if (file_exists($zip)) {
                    header($_SERVER["SERVER_PROTOCOL"] . " 200 OK");
                    header("Cache-Control: public"); // needed for internet explorer
                    header("Content-Type: application/zip");
                    header("Content-Disposition: attachment; filename=".basename($zip));
                    readfile($zip);
                    die();
                } else {
                    die("Error: File not found.");
                }
                break;
                
            default:
                $response = array( 
                                'success' => false,
                                'message' => 'Error: Invalid value passed for required parameter!' 
                            );
        }
    }else{
        $response = array( 
                        'success' => false,
                        'message' => 'Error: Missing required parameter!' 
                    );
    }
        
    echo json_encode( $response );
    exit;
?>